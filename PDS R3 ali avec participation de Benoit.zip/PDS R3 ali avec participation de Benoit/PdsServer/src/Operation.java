

public class Operation {
	private String Operation ;

	public Operation() {
		
	}

	public Operation(String operation) {
			this.Operation = operation;
	}


	public String getOperation() {
		return Operation;
	}

	public void setOperation(String operation) {
		this.Operation = operation;
	}


}
