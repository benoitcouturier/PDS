
import java.awt.BorderLayout;
import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.ObjectInputStream;
import java.io.PrintStream;
import java.net.Socket;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextArea;


public class ViewRoute extends JFrame implements ActionListener
{
	private JComboBox idProfil;
	private JTextArea resultat;
	private JButton submit;
	private BufferedReader in;
	private PrintStream out;
	private Socket s;
	public ViewRoute(BufferedReader in, PrintStream out, Socket s) throws HeadlessException {
		super();
		try {
			System.out.println("ok");
		JPanel panEast = new JPanel();
		panEast.add(resultat);
		this.setLayout(new BorderLayout());
		this.getContentPane().add(panEast, BorderLayout.EAST);
		JPanel panWest = new JPanel();
		panWest.setLayout(new BorderLayout());
		submit = new JButton("envoyer");
		submit.addActionListener(this);
		idProfil = new JComboBox();
		panWest.add(submit, BorderLayout.EAST);
		panWest.add(idProfil, BorderLayout.WEST);
		this.getContentPane().add(panWest, BorderLayout.WEST);
		this.in=in;
		this.out=out;
		out.println("SELECTUserIDRoute");
        out.flush();
        String res;

        res= in.readLine();
        System.out.println(res);
        if(res.equals("Null")) {

        }
        else {
            while (res != null) {
            	System.out.println("fed");
            	idProfil.addItem(res);
				System.out.println("ok");
           	 	if (in.ready()) {
           	 		res=in.readLine();
           	 	} else {
           	 		break;
           	 	}
       	 	}
        }
		this.setSize(400, 400);
		this.setVisible(true);
		}catch (Exception E) {
		}
		this.s=s;
	}
	@Override
	public void actionPerformed(ActionEvent arg0) {
		// TODO Auto-generated method stub
		try {
			ObjectInputStream obIn=new ObjectInputStream(s.getInputStream());

			out.print("SubmitRoute");
			out.flush();
			out.print(idProfil.getSelectedItem().toString());
			out.flush();
			HMRoute hM = (HMRoute) obIn.readObject();
			hM.sortID();
			hM.printValues(resultat);
		} catch (Exception e) {}
	}
	public static void main(String[] args) {

	}

}

