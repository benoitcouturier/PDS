

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import javax.swing.JTextArea;

public class HMRoute implements Serializable{
	private ArrayList<Integer> idLoc;
	private HashMap<Integer,String> hM;
	public HMRoute(){
		hM=new HashMap<>();
		idLoc = new ArrayList();
	}
	public void addItem(int key,String value){
		hM.put(key, value);
		idLoc.add(key);
	}
	public void sortID(){
		int size=idLoc.size();
		boolean sortlist = false;
		while (!sortlist) {
		    sortlist = true;
		    for(int i=0 ; i < size-1 ; i++) {
		          if((int) idLoc.get(i)<(int)idLoc.get(i+1)) {
		        	  int temp= (int) idLoc.get(i);
		        	  idLoc.set(i, idLoc.get(i+1));
		        	  idLoc.set(i+1, temp);
		        	  sortlist = false; 
		          }            
		    }
		    size--;
		}
	}
	public void printValues(JTextArea jTA) {
		int size=idLoc.size();
		 for(int i=0 ; i < size-1 ; i++) {
			 jTA.append(idLoc.get(i)+"     "+hM.get(idLoc.get(i))+"\n");
		 }
		
	}
}

