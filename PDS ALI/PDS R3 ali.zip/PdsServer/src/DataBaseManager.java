
import java.lang.reflect.InvocationTargetException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import org.json.simple.JSONObject;

public class DataBaseManager {
	
 
	public ResultSet Select(PoolConnexion pool2) throws ClassNotFoundException, SQLException {   
		Connection  conn = pool2.getConnexion();
		Statement state = conn.createStatement();
	    ResultSet result = state.executeQuery("SELECT * FROM Consumer");
	    pool2.ReturnConnectionTopool(conn);
	    return result ;
	}
	public ResultSet SelectNames(PoolConnexion pool2,String Name,String Prename)throws ClassNotFoundException, SQLException{
		Connection  conn = pool2.getConnexion();
		Statement state = conn.createStatement();
	    ResultSet result = state.executeQuery("SELECT * FROM Consumer where Name = '"+Name+"'and FirstName = '"+Prename+"'" );
	    pool2.ReturnConnectionTopool(conn);
		return result;
	}
	public int Delect(String string,Connection conn) throws ClassNotFoundException, SQLException {   
		Statement state = conn.createStatement();
	    int result = state.executeUpdate("DELETE FROM SHOP where SHOPNAME = '"+string+"'");
		return result ;
	}
	public int Delect2(String string,Connection conn) throws ClassNotFoundException, SQLException {   
		Statement state = conn.createStatement();
	    int result = state.executeUpdate("DELETE FROM SHOP where IDSHOP = '"+string+"'");
		return result ;
	}
	public ResultSet Select2(String string,Connection conn) throws ClassNotFoundException, SQLException {   
		Statement state = conn.createStatement();
	    ResultSet result = state.executeQuery("SELECT * FROM SHOP where SHOPNAME = '"+string+"'");
		return result ;
	}
	public ResultSet Select3(String string,Connection conn) throws ClassNotFoundException, SQLException {   
		Statement state = conn.createStatement();
	    ResultSet result = state.executeQuery("SELECT * FROM SHOP where IDSHOP = '"+string+"'"); 
		return result ;
	}
	





}