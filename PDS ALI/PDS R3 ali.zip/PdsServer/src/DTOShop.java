

public class DTOShop {
	private String FirstName;
	private String Name;
    private String DateOfPurchase;
    private String ModeOfPurchase;
    private String Price;
    private String Profile;
	private String Product;
	private String Operation;
	public DTOShop(String firstName, String name, String dateOfPurchase, String modeOfPurchase, String price,String Profile, String product,String Operation) {
		super();
		FirstName = firstName;
		Name = name;
		DateOfPurchase = dateOfPurchase;
		ModeOfPurchase = modeOfPurchase;
		this.Price = price;
		this.Profile = Profile;
		Product = product;
		this.Operation = Operation;
	}
	
	
	public String getOperation() {
		return Operation;
	}


	public void setOperation(String operation) {
		Operation = operation;
	}


	public DTOShop() {}
	
	public String getFirstName() {
		return FirstName;
	}
	public void setFirstName(String firstName) {
		FirstName = firstName;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public String getDateOfPurchase() {
		return DateOfPurchase;
	}
	public void setDateOfPurchase(String dateOfPurchase) {
		DateOfPurchase = dateOfPurchase;
	}
	public String getModeOfPurchase() {
		return ModeOfPurchase;
	}
	public void setModeOfPurchase(String modeOfPurchase) {
		ModeOfPurchase = modeOfPurchase;
	}
	public String getPrice() {
		return Price;
	}
	public void setPrice(String Price) {
		this.Price = Price;
	}
	public String getProfile() {
		return Profile;
	}
	public void setProfile(String paymentChoice) {
		Profile = paymentChoice;
	}
	public String getProduct() {
		return Product;
	}
	public void setProduct(String product) {
		Product = product;
	}



}
