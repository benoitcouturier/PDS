package server;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class ConnectionThread implements Runnable {
 public ServerSocket serversocket;
 public Socket socket;
 public Server server;
 public  PoolConnexion pool;
 
 public ConnectionThread(ServerSocket serversocket,Server server, PoolConnexion pool,Socket socket) {
	 this.serversocket=serversocket;
	 this.socket=socket;
	 this.pool=pool;
	 this.socket=socket;
 }
 public void run(){
	 try {
		while(true) {
		System.out.println("client trouver");
		Service service = new Service(socket,server,pool);
		service.run();
		}
	 } catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	 
	 
	 
 }
	
	
}
