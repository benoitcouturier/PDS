package server;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ArrayList;

public class PoolThread {
	static  ArrayList<Socket> pool = new ArrayList<Socket>();
	static int Connectionused=0;
	static int port;
	 
	
	 public PoolThread(int port ) throws IOException {
		this.port=port;
		ServerSocket conn = new ServerSocket(port);
   
		for( int j=0;j<10;j++) {
    	pool.add(conn.accept());
		}

	 }
	public void ReturnConnectionTopool(Socket conn) {
		this.pool.add(conn);
		this.Connectionused=this.Connectionused-1;
	}
	 public Socket getConnexion() {
		 Connectionused++;
		 Socket conn = pool.get(0);
		 pool.remove(0);
		 return conn;
		}
	
}
