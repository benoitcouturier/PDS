package server;
import java.lang.reflect.InvocationTargetException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import org.json.simple.JSONObject;

public class DataBaseManager {
	
 
	public ResultSet Select(PoolConnexion pool2) throws ClassNotFoundException, SQLException {   
		Connection  conn = pool2.getConnexion();
		Statement state = conn.createStatement();
	    ResultSet result = state.executeQuery("SELECT * FROM Commande");
	    pool2.ReturnConnectionTopool(conn);
	    return result ;
	}
	public ResultSet SelectNames(PoolConnexion pool2,String Name,String Prename)throws ClassNotFoundException, SQLException{
		Connection  conn = pool2.getConnexion();
		Statement state = conn.createStatement();
	    ResultSet result = state.executeQuery("SELECT * FROM Commande where Name = '"+Name+"'and FirstName = '"+Prename+"'" );
	    pool2.ReturnConnectionTopool(conn);
		return result;
	}
	
	public int update(String name, String firstName, String profile, String moyenneachat,PoolConnexion pool2) throws SQLException {
		// TODO Auto-generated method stub
		Connection  conn = pool2.getConnexion();
		Statement state = conn.createStatement();
	    int result = state.executeUpdate("UPDATE Client SET profile ='"+profile+"', Price = '"+moyenneachat+" $"+"'where name = '"+name+"'and firstName = '"+firstName+"'");
	    pool2.ReturnConnectionTopool(conn);
		return result;
	}
	
	public int updateprofile(String name, String firstName, String profile,PoolConnexion pool2) throws SQLException {
		// TODO Auto-generated method stub
		Connection  conn = pool2.getConnexion();
		Statement state = conn.createStatement();
	    int result = state.executeUpdate("UPDATE Client SET profile ='"+profile+"'where name = '"+name+"'and firstName = '"+firstName+"'");
	    pool2.ReturnConnectionTopool(conn);
		return result;
	}




}