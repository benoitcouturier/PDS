import java.io.BufferedReader;
import java.io.PrintStream;
import java.net.Socket;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;

public class ControllerViewGroup {
	private ViewGroup view;
	private EventHandler<ActionEvent> Button1;
	private EventHandler<ActionEvent> Button2;
	private EventHandler<ActionEvent> Button3;
	private EventHandler<ActionEvent> Button4;
	BufferedReader in;
	PrintStream out;
	ViewGroup viewGroup;
	Socket socket;
	


	public ControllerViewGroup(Socket socket2, BufferedReader in2, PrintStream out2, ViewGroup viewGroup2) {
	
		// TODO Auto-generated constructor stub
		this.socket=socket2;
		this.in=in2;
		this.out=out2;
		this.view=viewGroup2;
	}



	public void control() {
	
	Button1 = e ->{
			// part of Ali banhakeia
		try {
		// the principal view
		View view2 = new View();
		view2.getStage1().show();
		ControllerView controlview = new ControllerView(view2,in,out,socket);
		controlview.Control();
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}; view.getButton1().setOnAction(Button1);
	
	
	
	Button2 = e ->{
	// part of Ludovic 
		
	
	
	
	}; view.getButton2().setOnAction(Button2);

	
	Button3 = e ->{
	// part of Benoit
	
	
	}; view.getButton3().setOnAction(Button3);
	
	Button4 = e ->{
	// part of Kamal
	
	
	
	
	}; view.getButton4().setOnAction(Button4);



	}
	
	
}
