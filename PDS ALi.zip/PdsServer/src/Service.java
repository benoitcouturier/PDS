import java.io.BufferedReader;

import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.lang.reflect.InvocationTargetException;
import java.net.Socket;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.swing.JTextArea;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;


public class Service {
private Socket socket;
Server msg;
int i;
ResultSet result ;
PoolConnexion pool;
public Service (Socket socket,Server msg,PoolConnexion pool) {
	this.socket=socket;
	this.msg=msg;

	this.pool=pool;
}

public void run(){
	try{
	System.out.println("nous avons entrer");
	msg.msg.append("\nAUTHENTIFICATION  with ");
	msg.msg.append("\nAUTHENTIFICATION  with "+" Client is " +socket.getInetAddress().getHostAddress());
    BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
    PrintStream out = new PrintStream(socket.getOutputStream());
    String compte;
	while(true) {
		compte = in.readLine();
		String pass = in.readLine();
		if(compte.equals("GAMMA") && pass.equals("GAMMA")) {
			msg.msg.append("\nConnexion successfully with  new Client is " +socket.getInetAddress().getHostAddress());
			out.println("true");
			out.flush();
    	break;
    	}   
		else {
			out.println("false");
			out.flush();	
			msg.msg.append("\n error identification Client"+socket.getInetAddress().getHostAddress());
		}
    }
    
    while(true) {
    	String Operation = in.readLine();
    	Serialisation serialisation = new Serialisation();
    	JSONObject json;
    	JSONArray jsonarray;
    	ArrayList<Object> dtos = new ArrayList<Object>();
    	DataBaseManager base = new DataBaseManager();
    	json = serialisation.deserialisation(Operation);
    	System.out.println(json);
    		if(json.get("Operation").equals("Select-The-Table-Consumer")) {
    			msg.msg.append("\nSelect from Client"+socket.getInetAddress().getHostAddress());
    			result = base.Select(pool);
    			if (result.next()==(false)) {
    				out.println("Null");  
    				out.flush();
    			}
    			result.previous();
    			while(result.next()){      
    		    	System.out.println("1");
    				DTOShop shop = new DTOShop(); 
    				shop.setFirstName(result.getString("FirstName"));
    				shop.setName(result.getString("Name"));
    				shop.setPrice(result.getString("Price"));
    				shop.setProduct(result.getString("Product"));
    				shop.setModeOfPurchase(result.getString("ModeOfPurchase"));
    				shop.setDateOfPurchase(result.getString("DateOfPurchase"));
    				shop.setProfile(result.getString("Profile"));
    				dtos.add(shop);
    			}
    			jsonarray =serialisation.serialisationDTOArray(dtos);
				System.out.println(jsonarray.toJSONString());
				out.println(jsonarray.toJSONString());
				out.flush();
    			
    	
    	}else if (json.get("Operation").equals("Select Consumer from The Table Consumer")) {
    		msg.msg.append("\nSelect names from Client"+socket.getInetAddress().getHostAddress());
    		String Name,FirstName;
    		Name = in.readLine();
    		System.out.println(Name);
    		FirstName = in.readLine();
    		System.out.println(FirstName);
    		result = base.SelectNames(pool,Name,FirstName);
    		if (result.next()==(false)) {
				out.println("Null");
				out.flush();
			}
			result.previous();
			while(result.next()){      
		    	System.out.println("1");
				DTOShop shop = new DTOShop(); 
				shop.setFirstName(result.getString("FirstName"));
				shop.setName(result.getString("Name"));
				shop.setPrice(result.getString("Price"));
				shop.setProduct(result.getString("Product"));
				shop.setModeOfPurchase(result.getString("ModeOfPurchase"));
				shop.setDateOfPurchase(result.getString("DateOfPurchase"));
				shop.setProfile(result.getString("Profile"));
				dtos.add(shop);
			}
			jsonarray =serialisation.serialisationDTOArray(dtos);
			System.out.println(jsonarray.toJSONString());
			out.println(jsonarray.toJSONString());
			out.flush();
    		
    	}
    		
    	
    
    	
 
    
    }
 
    } catch (Exception e) {} 
}
}
