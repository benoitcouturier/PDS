
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class ConnectionThread implements Runnable {
 public ServerSocket serversocket;
 public Socket socket;
 public Server server;
 public  PoolConnexion pool;
 
 public ConnectionThread(ServerSocket serversocket,Server server, PoolConnexion pool) {
	 this.serversocket=serversocket;
	 this.socket=socket;
	 this.pool=pool;
 }
 public void run(){
	 try {
		while(true) {
		socket = serversocket.accept();
		System.out.println("client trouver");
		Service service = new Service(socket,server,pool);
		service.run();
		}
	 } catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	 
	 
	 
 }
	
	
}
