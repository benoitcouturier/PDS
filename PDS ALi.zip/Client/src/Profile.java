import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

public class Profile  {
	String profile;
	float price;
	float commands;
	float resulte ;
	Label label = new Label("Hello Worlds");
	ImageView SelectedImage;
	Stage arg0 = new Stage();
	public Profile() {
		
	}
	public Profile(float price,float commands) {
		this.price=price; this.commands=commands;
		this.resulte =price+commands;
	}
	public float getResulte() {
		return resulte;
	}

	public void setResulte(float resulte) {
		this.resulte = resulte;
	}


 

	public String getProfile() {
		return profile;
	}

	public void setProfile(String profile) {
		this.profile = profile;
	}

	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}

	public float getCommands() {
		return commands;
	}

	public void setCommands(float commands) {
		this.commands = commands;
	}

	public void setStageArg0(Stage arg0) {
		this.arg0 = arg0;
	}

	public Label getLabel() {
		return label;
	}

	public void setLabel(Label label) {
		this.label = label;
	}

	public Stage start() throws Exception {
		GridPane grid = new GridPane();
		label.setTextFill(Color.AQUA);
		grid.setPadding(new Insets(10, 10, 10, 10));
		grid.setVgap(1);
		grid.setHgap(3);
		GridPane.setConstraints(label, 1, 1);
        grid.getChildren().add(label);
        grid.setStyle("-fx-background-color: black");
		Scene scene = new Scene(grid, 500, 50);
        arg0.setTitle("Test de GridPane"); 
        arg0.setScene(scene); 
		return arg0;
	}

	

	
}
