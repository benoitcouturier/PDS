import java.io.BufferedReader;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintStream;
import java.lang.reflect.InvocationTargetException;
import java.net.Socket;
import java.util.ArrayList;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import com.sun.xml.internal.ws.developer.Serialization;

import javafx.beans.InvalidationListener;
import javafx.beans.Observable;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.Button;

public class ControllerView {
	private EventHandler<ActionEvent> SELECT;
	private Socket Socket;
	private BufferedReader In;
	private PrintStream Out;
	private View ViewClient;
	private static ArrayList<String> Names = new ArrayList<String>() ;
	private static ArrayList<String> FirstName = new ArrayList<String>();
	
	public ControllerView(View view2,BufferedReader in,PrintStream out,Socket socket ) {
		this.In=in;
		this.ViewClient=view2;
		this.Out=out;
		this.Socket=socket;
	}

	// method serves to remove elements double many times in List
	public static ArrayList<String> Start(ArrayList<String> array) {
		for(int i=0;i<array.size();i++) {
			for(int j=i+1;j<array.size();j++) {
				if(array.get(i).equals(array.get(j))) {
					array.remove(j);
				}
			}
		}
		
		return array;
	}
	
	// method serves to find the maximum from list of profiles
	public Profile getProfilePrice(ArrayList<Profile> x) {
		float Max=0;
		int z = 0;
		for(int i=0;i<x.size();i++) {
			Profile y = x.get(i);
			System.out.println(y.getResulte());
			if(Max<y.getResulte()) {
				Max=y.getResulte();
				z=i;
				System.out.println(Max);
			}
			System.out.println("aLi");
		}
		
		return x.get(z);
		
	}


	public void Control() {
		DTOShopt DTO = new DTOShopt();
		Operation operation = new Operation();
		Serialisation sr = new Serialisation();
		
		ViewClient.getListview().setVisible(false); 
		ViewClient.getListviewfn().setVisible(false);	
		
		ViewClient.getListviewfn().setOnMouseClicked(new EventHandler<MouseEvent>() {

			@Override
			public void handle(MouseEvent event) {
				ViewClient.getFirstName().setText(ViewClient.getListviewfn().getSelectionModel().getSelectedItem().toString());
				ViewClient.getListviewfn().setVisible(false);
			}
	    			});
		// serves for automatic search for FirstName
		ViewClient.getFirstName().setOnKeyPressed(new EventHandler<KeyEvent>() {
			
	    		String string ="";
	    		public void handle(KeyEvent ke) { 	
	    			int a=0;
	    			ViewClient.getListviewfn().setVisible(true);
	    			string =ViewClient.getFirstName().getText();
	    			System.out.println(string+"   ecri");
	    			ViewClient.getItems2().clear();
	    			for (int i=0;i<FirstName.size();i++) {
	    				if(FirstName.get(i).length()>string.length()) {
	    					if( FirstName.get(i).substring(0,string.length()).equals(string)) {
	    						System.out.println("egalite verifier");
	    						ViewClient.getItems2().add(FirstName.get(i));	
	    						ViewClient.getListviewfn().setItems(ViewClient.getItems2());   
	    						a++;
	    					}		
	    					
	    					
	    				}
	    		}
			      if(ViewClient.getFirstName().getText().equals("")) {
			    	  ViewClient.getListviewfn().setVisible(false); 
			      }
			      else if(a==0) {ViewClient.getListviewfn().setVisible(false); }
			      
	    		}
	    	});
	    
		// serves for automatic search for Name
		ViewClient.getListview().setOnMouseClicked(new EventHandler<MouseEvent>() {

			@Override
			public void handle(MouseEvent event) {
				
				ViewClient.getName().setText(ViewClient.getListview().getSelectionModel().getSelectedItem().toString());
				ViewClient.getListview().setVisible(false);
			}
		});
		ViewClient.getName().setOnKeyPressed(new EventHandler<KeyEvent>() {
			String string ="";
			public void handle(KeyEvent ke) { 	
				int a=0;
				ViewClient.getListview().setVisible(true);
				string =ViewClient.getName().getText();
				ViewClient.getItems().clear();
				for (int i=0;i<Names.size();i++) {
					if(Names.get(i).length()>string.length()) {
						if( Names.get(i).substring(0,string.length()).equals(string)) {
							ViewClient.getItems().add(Names.get(i));	
							ViewClient.getListview().setItems(ViewClient.getItems());   
							a++;
						}		 
					}
			 }
			 if(ViewClient.getName().getText().equals("")) {
				 ViewClient.getListview().setVisible(false); 
				}
			 else if(a==0) {ViewClient.getListview().setVisible(false); }
			
			}
        });
		
		// When we click on the button the obeject e is launched
		
		SELECT = e ->{
			
			try {	
				 float numberOfCommands=0,inf=0,spor=0,deco=0,vg=0,tsp=0,te=0,cars=0,games=0;
				 float totalprice=0,infp=0,sporp=0,decop=0,vgp=0,tspp=0,tep=0,carsp=0,gamesp=0;
				
				if (ViewClient.getName().getText().equals("") && ViewClient.getFirstName().getText().equals("")) {
					try {
						operation.setOperation("Select-The-Table-Consumer");
						JSONObject object =new JSONObject();
						JSONArray array =new JSONArray();
						object =sr.serialisationDTO(operation);
						System.out.println(object.toJSONString());
						Out.println(object.toJSONString());
						Out.flush();
						String res;
						res= In.readLine();
						System.out.println(res);
						ViewClient.getData().clear();
						if(res.equals("Null")) {
	                
						}
	                
						else {
	           
							while(res != null){
								array = sr.deserialisationarray(res);
								for (int p=0;p<array.size();p++) {
									JSONObject object1 = (JSONObject) array.get(p);
									DTOShopt dto = new DTOShopt((String)object1.get("FirstName"),(String)object1.get("Name"),(String)object1.get("DateOfPurchase"),(String)object1.get("ModeOfPurchase"),(String)object1.get("Price"),(String)object1.get("Profile"),(String)object1.get("Product"),(String)object1.get("Operation"));
									System.out.println(object1.toString());
									ViewClient.getData().add(dto);
									FirstName.add((String)object1.get("FirstName"));
									 Names.add((String)object1.get("Name"));
									}
								FirstName= Start(FirstName);
								Names=     Start(Names);
								
								if(In.ready()){
									res=In.readLine();
								}else{
									break;
								}
	               	 
								
							}
							
							}
	               	
	              
	                
						}catch(Exception e6) {}
				}else if(ViewClient.getName().getText()!="" && ViewClient.getName().getText()!="") {
					numberOfCommands = 0;
					totalprice=0;
					DTO.setOperation("Select Consumer from The Table Consumer");
					JSONObject object =new JSONObject();
					JSONArray array =new JSONArray();
					object =sr.serialisationDTO(DTO);
					Out.println(object.toJSONString());
	                Out.flush();
	                Out.println(ViewClient.getName().getText());
	                Out.flush();
	                Out.println(ViewClient.getFirstName().getText());
	                Out.flush();
	                String res;
	                res= In.readLine();
	                ViewClient.getData().clear();
	                if(res.equals("Null")) {
	                	
	                }
	                else {
	                	while(res != null){
	                		
	                		array = sr.deserialisationarray(res);
	                		for (int p=0;p<array.size();p++) {
	                			JSONObject object1 = (JSONObject) array.get(p);
	                			DTOShopt dto = new DTOShopt((String)object1.get("FirstName"),(String)object1.get("Name"),(String)object1.get("DateOfPurchase"),(String)object1.get("ModeOfPurchase"),(String)object1.get("Price"),(String)object1.get("Profile"),(String)object1.get("Product"),(String)object1.get("Operation"));
	                			
	                			ViewClient.getData().add(dto);
	                			numberOfCommands++;
	                			totalprice=totalprice+Integer.parseInt((String)object1.get("Price"));
	                			String x=(String)object1.get("Profile");
	                			
	                			System.out.println(x+"------");
	                			if(x.equals("Informatique")) {
	                				inf= inf+1;
	                				infp=infp+Integer.parseInt((String)object1.get("Price"));
	                				System.out.println(inf+"++++++++++++++++\n");
	                			}
	                			else if(x.equals("Sport")) {
	                				spor++; 
	                				sporp=sporp+Integer.parseInt((String)object1.get("Price"));
	                			
	                			}
	                			else if(x.equals("Decoration")) {
	                				deco++;
	                				decop=decop+Integer.parseInt((String)object1.get("Price"));
	                			}
	                			else if(x.equals("Video-Games")) {
	                				vg++;
	                				vgp=vgp+Integer.parseInt((String)object1.get("Price"));
	                			}
	                			else if(x.equals("TV/Sound/Photo")) {
	                				tsp++;
	                				tspp=tspp+Integer.parseInt((String)object1.get("Price"));
	                			}
	                			else if(x.equals("Telephony")) {
	                				te++;
	                				tep=tep+Integer.parseInt((String)object1.get("Price"));
	                			}
	                			else if(x.equals("Cars")) {
	                				cars++;
	                				carsp=carsp+Integer.parseInt((String)object1.get("Price"));
	                			}
	                			else if(x.equals("Games")) {
	                				games++;
	                				gamesp=gamesp+Integer.parseInt((String)object1.get("Price"));
	                			}
	                		}
	                		System.out.println(numberOfCommands);
	                		System.out.println(inf);
	                		float r;float z;
	                		ArrayList<Profile> arrayMax = new ArrayList<Profile>();
	                		r=(inf/numberOfCommands)*100;
	                		z=(infp/totalprice)*100;
	                		Profile profile = new Profile(z,r);
	                		profile.setProfile("Informatique");
	                		arrayMax.add(profile);
	                		ViewClient.getLabel1P().setText(String.valueOf(r)+"%");
	                		ViewClient.getLabel1PP().setText(String.valueOf(z)+"%");
	                		r=(spor/numberOfCommands)*100;
	                		z=(sporp/totalprice)*100;
	                		profile.setProfile("Sport");
	                		profile = new Profile(z,r);
	                		arrayMax.add(profile);
	                		ViewClient.getLabel2P().setText(String.valueOf(r)+"%");
	                		ViewClient.getLabel2PP().setText(String.valueOf(z)+"%");
	                		r=(deco/numberOfCommands)*100;
	                		z=(decop/totalprice)*100;
	                		profile.setProfile("Decoration");
	                		profile = new Profile(z,r);
	                		arrayMax.add(profile);
	                		ViewClient.getLabel3P().setText(String.valueOf(r)+"%");
	                		ViewClient.getLabel3PP().setText(String.valueOf(z)+"%");
	                		r=(vg/numberOfCommands)*100;
	                		z=(vgp/totalprice)*100;
	                		profile.setProfile("Video-Games");
	                		profile = new Profile(z,r);
	                		arrayMax.add(profile);
	                		ViewClient.getLabel4P().setText(String.valueOf(r)+"%");
	                		ViewClient.getLabel4PP().setText(String.valueOf(z)+"%");
	                		profile.setProfile("TV/Sound/Photo");
	                		r=(tsp/numberOfCommands)*100;
	                		z=(tspp/totalprice)*100;
	                		profile = new Profile(z,r);
	                		arrayMax.add(profile);
	                		ViewClient.getLabel5P().setText(String.valueOf(r)+"%");
	                		ViewClient.getLabel5PP().setText(String.valueOf(z)+"%");
	                		profile.setProfile("Telephony");
	                		r=(te/numberOfCommands)*100;
	                		z=(tep/totalprice)*100;
	                		profile = new Profile(z,r);
	                		arrayMax.add(profile);
	                		ViewClient.getLabel6P().setText(String.valueOf(r)+"%");
	                		ViewClient.getLabel6PP().setText(String.valueOf((tep/totalprice)*100)+"%");
	                		profile.setProfile("Cars");
	                		r=(cars/numberOfCommands)*100;
	                		z=(carsp/totalprice)*100;
	                		profile = new Profile(z,r);
	                		arrayMax.add(profile);
	                		ViewClient.getLabel7P().setText(String.valueOf(r)+"%");
	                		ViewClient.getLabel7PP().setText(String.valueOf(z)+"%");
	                		profile.setProfile("Games");
	                		r=(games/numberOfCommands)*100;
	                		z=(gamesp/totalprice)*100;
	                		profile = new Profile(z,r);
	                		arrayMax.add(profile);
	                		ViewClient.getLabel8P().setText(String.valueOf(r)+"%");
	                		ViewClient.getLabel8PP().setText(String.valueOf(z)+"%");
	                		Profile pr = new Profile();
	                		System.out.println("Profile of "+ViewClient.getName().getText()+" "+ViewClient.getFirstName().getText()+" is "+getProfilePrice(arrayMax).getProfile());
	                		pr.getLabel().setText("the Profil of "+ViewClient.getName().getText()+" "+ViewClient.getFirstName().getText()+" is :  "+getProfilePrice(arrayMax).getProfile());
	                		pr.start().show();
	                		System.out.println(numberOfCommands);
	                		
	                		if(In.ready()){
			               	 res=In.readLine();
	                		}else{
			                	break;
	                		}
					
					
					
					
					
			 }
			 
			
			 
			   
	                }
			 }
			
		}catch(Exception e6) {}
		};ViewClient.getImport().setOnAction(SELECT);
	}}
		
	
				    
	

			
		
	