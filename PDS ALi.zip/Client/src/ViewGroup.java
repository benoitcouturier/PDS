import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

public class ViewGroup {

	Button button1 = new Button("  Banhakeia  ");
	Button button2 = new Button("    Benoit   ");
	Button button3 = new Button("    Loduvic  ");
	Button button4 = new Button("    Kamal    ");
	ImageView SelectedImage;
	Stage arg0 = new Stage();
	
	public Stage start() throws Exception {
		GridPane grid = new GridPane();
		grid.setPadding(new Insets(10, 10, 10, 10));
		grid.setVgap(6);
		grid.setHgap(4);
		
		GridPane.setConstraints(button1, 0, 0);
        grid.getChildren().add(button1);
        
        GridPane.setConstraints(button2, 1, 1);
        grid.getChildren().add(button2);
        
        GridPane.setConstraints(button3, 2, 2);
        grid.getChildren().add(button3);
        
        GridPane.setConstraints(button4, 3, 3);
        grid.getChildren().add(button4);
        
        
        grid.setStyle("-fx-background-color: black");
		Scene scene = new Scene(grid, 400, 140);
        arg0.setTitle("Test de GridPane"); 
        arg0.setScene(scene); 
		return arg0;
	}

	public Stage getArg0() {
		return arg0;
	}

	public void setArg0(Stage arg0) {
		this.arg0 = arg0;
	}

	public Button getButton1() {
		return button1;
	}

	public void setButton1(Button button1) {
		this.button1 = button1;
	}

	public Button getButton2() {
		return button2;
	}

	public void setButton2(Button button2) {
		this.button2 = button2;
	}

	public Button getButton3() {
		return button3;
	}

	public void setButton3(Button button3) {
		this.button3 = button3;
	}

	public Button getButton4() {
		return button4;
	}

	public void setButton4(Button button4) {
		this.button4 = button4;
	}


}
